Switch Between Languages/切换语言
=================================

The ESP-IDF Programming Manual is now available in two languages. Please refer to the English version if there is any discrepancy.

《ESP-IDF 编程手册》部分文档现在有两种语言的版本。如有出入请以英文版本为准。

- English/英文
- Chinese/中文

You can easily change from one language to another by the panel on the sidebar like below. Just click on the **Read the Docs** title button on the left-bottom corner if it is folded.

如下图所示，你可使用边栏的面板进行语言的切换。如果该面板被折叠，点击左下角 **Read the Docs** 标题按钮来显示它。

.. image:: /../_static/choose_version.png

