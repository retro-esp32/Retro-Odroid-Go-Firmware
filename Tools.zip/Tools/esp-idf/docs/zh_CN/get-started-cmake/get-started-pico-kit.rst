.. include:: ../../en/get-started-cmake/get-started-pico-kit.rst
