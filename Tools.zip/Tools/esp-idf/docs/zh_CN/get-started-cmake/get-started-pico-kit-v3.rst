.. include:: ../../en/get-started-cmake/get-started-pico-kit-v3.rst
