.. include:: ../../en/get-started-cmake/linux-setup-scratch.rst
