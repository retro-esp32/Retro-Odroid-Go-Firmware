.. include:: ../../en/get-started-cmake/add-idf_path-to-profile.rst
