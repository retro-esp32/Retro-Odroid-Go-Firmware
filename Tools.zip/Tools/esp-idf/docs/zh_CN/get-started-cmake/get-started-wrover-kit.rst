.. include:: ../../en/get-started-cmake/get-started-wrover-kit.rst
