.. include:: ../../en/get-started-cmake/eclipse-setup.rst
