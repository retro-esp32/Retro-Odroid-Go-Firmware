.. include:: ../../en/get-started-cmake/get-started-devkitc-v2.rst
