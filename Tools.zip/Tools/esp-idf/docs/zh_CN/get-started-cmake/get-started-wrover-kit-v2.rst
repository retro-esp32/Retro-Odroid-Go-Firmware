.. include:: ../../en/get-started-cmake/get-started-wrover-kit-v2.rst
