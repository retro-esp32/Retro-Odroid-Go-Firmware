.. include:: ../../en/get-started-cmake/windows-setup-scratch.rst
