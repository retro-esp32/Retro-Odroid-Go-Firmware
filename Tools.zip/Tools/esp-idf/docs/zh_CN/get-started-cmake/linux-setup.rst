.. include:: ../../en/get-started-cmake/linux-setup.rst
