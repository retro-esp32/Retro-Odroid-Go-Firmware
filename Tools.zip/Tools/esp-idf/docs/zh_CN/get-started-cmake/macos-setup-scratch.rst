.. include:: ../../en/get-started-cmake/macos-setup-scratch.rst
