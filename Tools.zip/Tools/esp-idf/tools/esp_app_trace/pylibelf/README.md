pylibelf
========

Python binding for libelf. 

